import { Player } from './player';

export class Game {
    gameStatus: string;
    players: Array<Player>;
    lastUpdate: Date;
    playerTurn: number;
}
