export class Player {
    id: number;
    playerName: string;
    pits: Array<number>;
    house: number;
}
