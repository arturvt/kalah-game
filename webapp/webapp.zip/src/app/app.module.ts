import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { GameComponent } from './game/game.component';
import { PlayerComponent } from './player/player.component';
import { GamedataService } from './gamedata.service';


@NgModule({
  declarations: [
    AppComponent,
    GameComponent,
    PlayerComponent
  ],
  imports: [
    BrowserModule, HttpClientModule
  ],
  providers: [GamedataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
