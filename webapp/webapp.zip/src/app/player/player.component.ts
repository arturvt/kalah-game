import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Player } from '../models/player';
import { GamedataService } from '../gamedata.service';

@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.scss']
})
export class PlayerComponent {

  @Input() player: Player;
  @Input() isTurn: boolean;
  @Output() playIndex: EventEmitter<number> = new EventEmitter<number>();
  constructor(private gameData: GamedataService) { }

  onClick(index: number) {
    if (this.isTurn) {
      this.playIndex.emit(index);
    }
  }

  getReversed(): number[] {
    return [5, 4, 3, 2, 1, 0];
  }

}
