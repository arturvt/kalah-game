import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Game } from './models/game';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class GamedataService {

  constructor(private http: HttpClient) { }

  play(index: number): Observable<Game> {
    return this.http.get<Game>('/api/play/' + index);
  }

  init(): Observable<Game> {
    return this.http.get<Game>('/api/init');
  }

}
