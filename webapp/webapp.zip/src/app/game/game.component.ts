import { Component, OnInit } from '@angular/core';
import { GamedataService } from '../gamedata.service';
import { Game } from '../models/game';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.scss']
})
export class GameComponent {

  game: Game;
  constructor(private gameData: GamedataService) { }

  startGame() {
    this.gameData.init().subscribe(data => this.game = data);
  }

  performPlay(index: number) {
    this.gameData.play(index).subscribe(data => this.game = data);
  }

}
